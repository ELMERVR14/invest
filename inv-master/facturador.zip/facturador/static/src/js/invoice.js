odoo.define('module.Sunat', function (require) 
{
    "use strict";
    var rpc = require('web.rpc');

$(document).ready(function()
{
    var flagLoaded = false;
    
    setInterval(function(){ 
        var invoice_number = $("span[name=number]").text();
        var firstPart = invoice_number.substring(0, 2);
        
        if(firstPart=="FC" || firstPart=="FD")
        {
            $("button[name=202]").fadeOut();
            $(".o_statusbar_buttons button").each(function(){
                var textButton = $(this).text();
                if(textButton.toLowerCase() == "emitir rectificativa" || textButton.toLowerCase() == "emitir nota")
                   $(this).fadeOut();
            });
        }
    if(!flagLoaded)
    {
      $(document).on("blur","input.vat", function()
        {
            var ruc = $("input.vat").val();
            var data = {"params": {'ruc':ruc}}
            $.ajax(
                   {
                    type: "POST",
                    url:'/sunatefact/get_ruc',            
                    data:JSON.stringify(data),            
                    dataType: 'json',    
                    contentType: "application/json",        
                    async: false,  
                    success: function (response)            
                    {            
                        if(response.result.status=="OK")        
                        {
                           $(".client-name").val(response.result.name);
                           $(".client-address-street").val(response.result.address);
                           $(".client-address-city").val(response.result.city);
                        }
                        else
                        {
                            alert(response.result.status);
                        }
                    }            
                   });
        })        
        flagLoaded = true; 
        $(document).on("click",".payment-screen .button", function()
        {
            if($(this).hasClass("next"))
            {
                var intervalId = setInterval(function()
                  { 
                    var posTop = $(".pos-center-align").text();
                    if(posTop!="")
                    {
                        var orderReference= posTop.split(" ");
                        var data = {"params": {'orderReference':orderReference[2]}}
                        $.ajax(
                                {
                                    type: "POST",
                                    url:'/sunatefact/get_invoice_qr',            
                                    data:JSON.stringify(data),            
                                    dataType: 'json',    
                                    contentType: "application/json",        
                                    async: false,  
                                    success: function (qrImage64)            
                                    {   
                                        var qrImageHTML = "<div style='text-align:center'><img src='data:image/png;base64,"+qrImage64.result+"' width='100' height='100' class='ticket_qr_image'/><div>"
                                        if($(".ticket_qr_image").length==0)
                                        {
                                          $(".pos-sale-ticket").append(qrImageHTML);
                                          clearInterval(intervalId);
                                        }
                                    }            
                                });                    
                    }
                    else  
                    {
                                           
                    }                    
                    
                }, 2500);
            }
        }) 

        $(document).on("click",".js_invoice", function()
        {
            if($(this).hasClass("button"))
            {
                var intervalIdInvoice = setInterval(function()
                  { 
                    var js_invoice = $(".js_invoice");
                    if(js_invoice.hasClass("highlight"))
                    {
                        if($(".journal-container-custom").length==0)
                        {
                            $.ajax(
                                    {
                                        type: "POST",
                                        url:'/sunatefact/get_invoice_ticket_journal',            
                                        data:JSON.stringify({}),            
                                        dataType: 'json',    
                                        contentType: "application/json",        
                                        async: false,  
                                        success: function (response)            
                                        {   console.log(response)
                                            if(response.result.journals!=null && response.result.journals!='') 
                                            {
                                                var journals = response.result.journals;
                                                var pos_config = response.result.pos_config;
                                                var option = '';
                                                journals.forEach(function(journal, index) 
                                                  {
                                                      if(journal.id>0)
                                                         option += '<option value="'+journal.id+'">'+journal.name+'</option>';
                                                  });
                                                $(".payment-buttons").append("<div class='journal-container-custom'><label>Documento: </label><select id='journal_id' pos_id='"+pos_config.id+"' class='journal-pos-custom'>"+option+"</select></div>") ;
                                                //can't read classes from this addon default template definition, adding it on fire with jquery
                                                $(".journal-pos-custom").css("height","38px");
                                                $(".journal-pos-custom").css("font-size","16px");
                                                $(".journal-pos-custom").css("padding","5px");
                                                $(".journal-pos-custom").css("margin-left","0px");
                                                $(".journal-pos-custom").css("margin","5px");
                                                $(".journal-container-custom").css("font-size","18px");
                                                $("#journal_id").val(pos_config.invoice_journal_id);
                                            }
                                            
                                        }            
                                    });                              
                        }
                        clearInterval(intervalIdInvoice);             
                    }                    
                    
                }, 2500);
            }
        })

        $(document).on("change","#journal_id", function()
        {
            var intervalJournalSelect = setInterval(function()
                  { 
                    var pos_id = $("#journal_id").attr("pos_id");
                    console.log(pos_id)

                    var journal_new_id =  $("#journal_id").val();
                    console.log(journal_new_id)
                    var data = {"params": {'posID':pos_id,'journalID':journal_new_id}}
                    //console.log(data)
                    $.ajax(
                            {
                                type: "POST",
                                url:'/sunatefact/update_current_pos_conf',            
                                data:JSON.stringify(data),            
                                dataType: 'json',    
                                contentType: "application/json",        
                                async: false,  
                                success: function (qrImage64)            
                                {   
                                    clearInterval(intervalJournalSelect); 
                                }            
                            });  
                  }, 2500);
        })

    } 
    if($('.pos-content').length>0)
    {
        if($('.modal').length>0)
            {
            if($(".modal-body:contains('ESTADO: FAIL')"))
                $(".modal").fadeOut();
            
                var popUpDisplayed = $(".popups").find( '.modal-dialog:not(.oe_hidden)'); 
                var titleText = popUpDisplayed.find(".title").html();
                popUpDisplayed.find(".title").hide();
                popUpDisplayed.find(".body").html(titleText)                
            } 
    } 
   }, 5500);                   
 })
})
