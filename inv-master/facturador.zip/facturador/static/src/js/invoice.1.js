$(document).ready(function()
{
    var flagLoaded = false;
    setInterval(function(){ 
    var invoice_number = $("span[name=number]").text();
    var firstPart = invoice_number.substring(0, 2);
    if(firstPart=="FC" || firstPart=="FD")
    {
        $("button[name=202]").fadeOut();
    }
    if(!flagLoaded)
    {
      $(document).on("blur","input.vat", function()
        {
            var ruc = $("input.vat").val();
            var data = {"params": {'ruc':ruc}}
            $.ajax(
                   {
                    type: "POST",
                    url:'/sunatefact/get_ruc',            
                    data:JSON.stringify(data),            
                    dataType: 'json',    
                    contentType: "application/json",        
                    async: false,  
                    success: function (response)            
                    {            
                        if(response.result.status=="OK")        
                        {
                           $(".client-name").val(response.result.name);
                           $(".client-address-street").val(response.result.address);
                           $(".client-address-city").val(response.result.city);
                        }
                        else
                        {
                            alert(response.result.status);
                        }
                    }            
                   });
        })        
        flagLoaded = true; 
        $(document).on("click",".payment-screen .button", function()
        {
            if($(this).hasClass("next"))
            {
                var intervalId = setInterval(function()
                  { 
                    var posTop = $(".pos-center-align").text();
                    if(posTop!="")
                    {
                        var orderReference= posTop.split(" ");
                        var data = {"params": {'orderReference':orderReference[2]}}
                        $.ajax(
                                {
                                    type: "POST",
                                    url:'/sunatefact/get_invoice_qr',            
                                    data:JSON.stringify(data),            
                                    dataType: 'json',    
                                    contentType: "application/json",        
                                    async: false,  
                                    success: function (qrImage64)            
                                    {   
                                        var qrImageHTML = "<div style='text-align:center'><img src='data:image/png;base64,"+qrImage64.result+"' width='100' height='100' class='ticket_qr_image'/><div>"
                                        if($(".ticket_qr_image").length==0)
                                        {
                                          $(".pos-sale-ticket").append(qrImageHTML);
                                          clearInterval(intervalId);
                                        }
                                    }            
                                });                    
                    }
                    else  
                    {
                                           
                    }                    
                    
                }, 1000);
            }
        }) 
    } 
    if($('.modal').length>0)
    {
      if($(".modal-body:contains('ESTADO: FAIL')"))
         $(".modal").fadeOut();
      
         var popUpDisplayed = $(".popups").find( '.modal-dialog:not(.oe_hidden)'); 
         var titleText = popUpDisplayed.find(".title").html();
         popUpDisplayed.find(".title").hide();
         popUpDisplayed.find(".body").html(titleText)
         
    }     
   }, 1000);                   
})