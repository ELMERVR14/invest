# -*- coding: utf-8 -*-
from . import invoice
from . import account_invoice_refund
from . import res_partner
from . import ir_sequence
from . import res_company
from . import delivery_carrier
from . import stock_picking
from . import account_tax