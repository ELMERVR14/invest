from odoo import models, fields, api, tools, _

class account_invoice(models.Model):

    _inherit = 'account.tax'

    sunat_tributo = fields.Selection([('1000','IGV'),('2000','ISC'),('9995','Exportación'),('9996','Gratuito'),('9997','Exonerado'),('9998','Inafecto'),('9998','Otros conceptos de pago')], string='Sunat Tributo', default='1000')
    _columns = {"sunat_tributo":fields.Selection([('1000','IGV'),('2000','ISC'),('9995','Exportación'),('9996','Gratuito'),('9997','Exonerado'),('9998','Inafecto'),('9998','Otros conceptos de pago')], string='Sunat Tributo', default='1000')}