# -*- coding: utf-8 -*-
from odoo import http
from odoo.exceptions import Warning
import os
from odoo.http import request

from sunatservice.sunatservice import Service

class SunatEfact(http.Controller):

    @http.route('/sunatefact/get_ruc/', methods=['POST'], type='json', auth="public", website=True)
    def get_ruc(self, **kw):
        ruc = kw.get('ruc')
        xmlPath = os.path.dirname(os.path.abspath(__file__))+'/xml'
        xmlPath = xmlPath.replace("controllers", "models")
        response = {}
        if(ruc!=""):
            SunatService = Service()
            SunatService.setXMLPath(xmlPath)            
            response = SunatService.consultRUC(ruc)
            
        if not response:
            return { 
                     'ruc':ruc,
                     'status' :  "El RUC no fue encontrado en registros de SUNAT"
                   }
        else:
            return {
                        'status' :  "OK",
                        'ruc':ruc,
                        'address' : response['address'],
                        'name' : response['name'],
                        'city' : response['city']
                    }

    @http.route('/sunatefact/get_invoice_qr/', methods=['POST'], type='json', auth="public", website=True)
    def get_invoice_qr(self, **kw):
        orderReference = kw.get('orderReference')

        query = "select invoice_id from pos_order where pos_reference = '"+str(orderReference)+"'"
        request.cr.execute(query)    
        pos_sale = request.cr.fetchone()
        invoice_id = pos_sale[0]

        query = "select qr_image from account_invoice where id = "+str(invoice_id)
        request.cr.execute(query)    
        account_invoice = request.cr.fetchone()
        qr_image = account_invoice[0]
        return qr_image

    @http.route('/sunatefact/get_invoice_ticket_journal/', methods=['POST'], type='json', auth="public", website=True)
    def get_invoice_ticket_journal(self, **kw):
        response = {}
        uid = http.request.env.context.get('uid')

        query = "select id, name from account_journal where code in ('INV','FAC','BOL')"
        request.cr.execute(query)    
        journals = request.cr.dictfetchall()
        response["journals"] = journals

        
        query = "select pos_config.id, pos_config.invoice_journal_id from pos_config inner join pos_session on pos_session.user_id = "+str(uid)+" and state = 'opened'"
        request.cr.execute(query)    
        pos_config = request.cr.dictfetchone()
        response["pos_config"] = pos_config
                
        return response

    @http.route('/sunatefact/update_current_pos_conf/', methods=['POST'], type='json', auth="public", website=True)
    def update_current_pos_conf(self, **kw):

        posID = kw.get('posID')
        journalID = kw.get('journalID')
        response = {}

        query = "update pos_config set invoice_journal_id = "+str(journalID)+" where id = "+posID
        request.cr.execute(query) 
                
        return True